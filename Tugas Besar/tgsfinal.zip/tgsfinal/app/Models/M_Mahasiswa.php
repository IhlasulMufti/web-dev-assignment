<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class M_Mahasiswa extends Model
{
    use HasFactory;

    protected $table = 'tmhs';
    protected $primaryKey = 'id';

    protected $fillable = [
        'NIM', 'Nama', 'Alamat', 'Prodi'
    ];
}
