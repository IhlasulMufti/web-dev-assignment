@extends('layouts.default')

@section('content')
<div class="bg-success text-white p-4 mb-2">
    <h1 class="text-center">PERTEMUAN 13</h1>
    <h2 class="text-center">Pembuatan CRUD dengan Laravel</h2>
</div>


<div class="container">
    <div class="mx-5">
        <h1 class="py-4">Daftar Mahasiswa</h1>
        <a href="{{ url('create') }}" class="btn btn-primary">+ Tambah Mahasiswa</a>
    </div>

    <section class="p-3 mt-2 bg-secondary">
        <div class="mt-2 text-center">
            <table class="table table-striped table-bordered">
                <tr class="table-dark">
                    <th>NO</th>
                    <th>NIM</th>
                    <th>NAMA</th>
                    <th>ALAMAT</th>
                    <th>AKSI</th>
                </tr>
                @foreach ($data as $dataMahasiswa)
                <tr class="table-success">
                    <td>{{ ++$i }}</td>
                    <td>{{ $dataMahasiswa->NIM }}</td>
                    <td>{{ $dataMahasiswa->Nama }}</td>
                    <td>{{ $dataMahasiswa->Alamat }}</td>
                    <td>
                        <a href="{{ url('/show/' . $dataMahasiswa->id)}}" class="btn btn-warning">Edit</a>
                        <a href="{{ url('/destroy/' . $dataMahasiswa->id)}}" class="btn btn-danger">Hapus</a>
                    </td>
                </tr>
                @endforeach
            </table>
        </div>
    </section>
</div>

<footer>
    <div class="card-footer mt-3">
        <small class="text-muted">Copyrightn &copy; 2021 - Ihlasul. All Rights Reserve</small>
    </div>
</footer>
@endsection