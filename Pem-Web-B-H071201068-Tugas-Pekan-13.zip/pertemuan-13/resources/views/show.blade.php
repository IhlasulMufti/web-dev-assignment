@extends('layouts.default')

@section('content')
<div class="bg-success text-white p-4 mb-2">
    <h1 class="text-center">PERTEMUAN 13</h1>
    <h2 class="text-center">Pembuatan CRUD dengan Laravel</h2>
</div>

<div class="container p-5">
    <h3>Pendaftaran Mahasiswa</h3>
    <!--Awal Card Form-->
    <div class="card border-info mb-3">
        <div class="card-header">Edit Data Mahasiswa</div>
        <div class="card-body">
            <form method="POST" action="{{ url('/update/' . $data->id) }}" enctype="multipart/form-data">
                @csrf
                <div>
                    <label>NIM</label>
                    <input type="text" name="NIM" class="form-control" value="{{$data->NIM}}" placeholder="Input NIM Anda" required>
                </div>
                <div>
                    <label>NAMA</label>
                    <input type="text" name="Nama" class="form-control" value="{{$data->Nama}}" placeholder="Input Nama Anda" required>
                </div>
                <div>
                    <label>ALAMAT</label>
                    <textarea name="Alamat" class="form-control" placeholder="Input Alamat Anda" required> {{$data->Alamat}}</textarea>
                </div>

                <div class="py-3">
                    <button type="submit" class="btn btn-success">Simpan</button>
                    <button type="reset" class="btn btn-danger">Reset</button>
                </div>

                <div>
                    <a href="{{ url('/') }}" class="btn btn-primary">
                        Kembali ke Halaman Utama</a>
                </div>
            </form>
        </div>
    </div>
</div>
<!--Akhir Card Form-->
<footer>
    <div class="card-footer mt-3">
        <small class="text-muted">Copyrightn &copy; 2021 - Ihlasul. All Rights Reserve</small>
    </div>
</footer>
@endsection